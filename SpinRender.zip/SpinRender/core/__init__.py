"""
SpinRender core package
"""
